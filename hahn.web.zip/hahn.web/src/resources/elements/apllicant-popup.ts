import { DialogController } from 'aurelia-dialog';
import { autoinject } from 'aurelia-dependency-injection';
import { bindable } from 'aurelia-framework';
import { ApllicantService } from 'services/apllicantservice';
import { DialogService } from 'aurelia-dialog';
import { Prompt } from './confirmation-modal';
import { ValidationRules, ValidationController } from 'aurelia-validation';
import { BootstrapFormRenderer } from 'BootstrapFormRenderer';

@autoinject

export class apllicantpopup {
  reset: boolean = false;
  save: boolean = false;
  @bindable btnupdate: Element;
  @bindable btnrest: Element;
  @bindable btnsave: Element;
  controller: DialogController;
  dialogService: DialogService;

  countries: [] | any;
  @bindable data = {
    id: null,
    name: null,
    familyName: null,
    address: null,
    countryOfOrigin: null,
    eMailAdress: null,
    age: null,
    hired: false
  }

  private _ApplicantService;
  constructor(private validationController: ValidationController, dialogServiceob: DialogService, controllerob: DialogController, ApllicantServiceobj: ApllicantService) {
    this.validationController.addRenderer(new BootstrapFormRenderer());
    this.controller = controllerob;
    this.dialogService = dialogServiceob;
    this._ApplicantService = ApllicantServiceobj;

  }
  isEmpty(str) {
    return (!str || 0 === str.length);
  }
  blur() {
    if (!this.isEmpty(this.data.name)||
    !this.isEmpty(this.data.familyName)||
    !this.isEmpty(this.data.countryOfOrigin)||
    !this.isEmpty(this.data.eMailAdress)||
    !this.isEmpty(this.data.address)||
    !this.isEmpty(this.data.age)||
    this.data.name==true
    ) {
      this.reset = true;
      this.btnrest.classList.remove('not-allowed');
    }
    else {
      this.btnrest.classList.add('not-allowed');
      this.reset = false;
    }
  };
  activate(model) {
    this.data = model[0];
    this.save = model[1];
    this.countries = model[2];
  }
  bind() {
    if (this.save == true) {
      this.btnupdate.classList.add('hide');
      this.btnsave.classList.remove('hide');
    }
    else {
      this.btnsave.classList.add('hide');
      this.btnupdate.classList.remove('hide');
    }
    ValidationRules
      .ensure('name').required().minLength(5)
      .ensure('familyName').required().minLength(5)
      .ensure('address').required().minLength(10)
      .ensure('eMailAdress').required().email()
      .ensure('countryOfOrigin').required()
      .ensure('age').required().between(20, 60)
      .on(this.data); //apply validation rules to the current view-model
  }
  public submit() {
    this.validationController.validate().then(result => { //validate when a book is added
      if (result.valid) {
        let contact = JSON.parse(JSON.stringify(this.data));
        contact.age = Number(contact.age);
        contact.id = Math.floor(Math.random() * 6) + 1;
        this._ApplicantService.SaveApplicant(contact)
          .then(contact => {
            this.cleardata();
            this.controller.ok(contact);
            //this.dialogService.closeAll();
           }).catch(
            err => 
            {
              this.cleardata();
              this.controller.cancel(err);
            }
          );
      }
    });
  };
  update() {
    this.validationController.validate().then(result => { //validate when a book is added
      if (result.valid) {
        let contact = JSON.parse(JSON.stringify(this.data));
        contact.age = Number(contact.age);
        this._ApplicantService.UpdateApplicant(contact.id, contact)
          .then(contact => {
            this.cleardata();
            this.controller.ok(contact);
           }).catch(
            err => 
            {
              this.cleardata();
              this.controller.cancel(err);
            }
          );
      }
    });
  };
  clear() {
    this.dialogService.open({ viewModel: Prompt, model: 'Are you sure?' }).whenClosed(openDialogResult => {
      return openDialogResult;
    }).then((response) => {
      if (!response.wasCancelled) {
       this.cleardata();
      }
    });
  };
  cleardata()
  {
    this.data.id= null,
    this.data.name= null,
    this.data.familyName= null,
    this.data.address= null,
    this.data.countryOfOrigin= null,
    this.data.eMailAdress= null,
    this.data.age= null,
    this.data.hired= false
    this.blur();
  }
}



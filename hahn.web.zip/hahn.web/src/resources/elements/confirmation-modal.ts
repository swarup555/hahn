import {autoinject} from 'aurelia-dependency-injection';
import {DialogController} from 'aurelia-dialog';
@autoinject
export class Prompt {
  controller:DialogController;
  message;
  answer;
  constructor(controllerob:DialogController){
    this.controller = controllerob;
    this.answer = null;
    this.controller.settings.centerHorizontalOnly = true;
  }
   activate(message) {
      this.message = message;
   }
}

import { HttpClient } from "aurelia-http-client";
import { transient } from "aurelia-dependency-injection";

import api from '../config/api';

@transient()
export class ApllicantService {
  private http:HttpClient;
  contacts = [];

  constructor(http:HttpClient) {
    http.configure(x => x.withBaseUrl(api.dev + '/values/'));
    this.http = http;
  }
  GetApplicants() {
    let promise = new Promise((resolve, reject) => {
      this.http
        .get('GetApplicants')
        .then(data => {
          this.contacts = JSON.parse(data.response);
          resolve(this.contacts)
        }).catch(err => reject(err));
    });
    return promise;
  }
  SaveApplicant(contact) {
    let promise = new Promise((resolve, reject) => {
      this.http
        .post('SaveApplicant', contact)
        .then(data => {
          let newContact = JSON.parse(data.response);
          resolve(newContact);
        }).catch(err => reject(err));
    });
    return promise;
  }

  GetApplicantByID(id) {
    let promise = new Promise((resolve, reject) => {
      this.http
        .get("GetApplicantByID/"+id)
        .then(response => {
          let contact = JSON.parse(response.response);
          resolve(contact);
        }).catch(err => reject(err))
    });
    return promise;
  }

  DeleteApplicant(id) {
    let promise = new Promise((resolve, reject) => {
      this.http
        .delete('DeleteApplicant/'+id)
        .then(response => {
          let result = JSON.parse(response.response);
          resolve(result);
        })
        .catch(err => reject(err));
    });
    return promise;
  }

  UpdateApplicant(id, contact) {
    let promise = new Promise((resolve, reject) => {
      this.http
        .put('UpdateApplicant/'+id, contact)
        .then(response => {
          let contact = JSON.parse(response.response);
          resolve(contact);
        }).catch(err => reject(err));
    });
    return promise;
  }
}

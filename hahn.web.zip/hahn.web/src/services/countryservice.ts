import { HttpClient } from "aurelia-http-client";
import { inject } from "aurelia-framework";

import api from '../config/api';

@inject(HttpClient)
export class CountryService {
  private http:HttpClient;
  contacts = [];

  constructor(http:HttpClient) {
    this.http = http;
  }
  GetCountries() {
    let promise = new Promise((resolve, reject) => {
      this.http
        .get('https://restcountries.eu/rest/v2/all')
        .then(data => {
          this.contacts = JSON.parse(data.response);
          resolve(this.contacts)
        }).catch(err => reject(err));
    });
    return promise;
  }
 
}

import { autoinject } from 'aurelia-dependency-injection';
import { ApllicantService } from 'services/apllicantservice';
import { CountryService } from 'services/countryservice';
import { apllicantpopup } from './resources/elements/apllicant-popup';
import { DialogService } from 'aurelia-dialog';
import { Prompt } from './resources/elements/confirmation-modal'
import toastr from 'toastr';
@autoinject
export class App {
  public message: string = 'Hello World!';
  dialogService: DialogService;
  save: boolean = false;
  public data = {
    id: null,
    name: null,
    familyName: null,
    address: null,
    countryOfOrigin: null,
    eMailAdress: null,
    age: null,
    hired: false
  }

  results: [] | any;
  countries: [] | any;
  private _ApplicantService;
  private _CountryService;
  constructor(dialogServiceob: DialogService, CountryServiceobj: CountryService, ApllicantServiceobj: ApllicantService) {
    this._ApplicantService = ApllicantServiceobj;
    this._CountryService = CountryServiceobj;
    this.dialogService = dialogServiceob;
    this.GetApplicants();
    this.Countrylist();
  }
 
  openpopup() {
    this.save = true;
    this.dialogService.open({ viewModel: apllicantpopup, model: [this.data, this.save, this.countries], lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
        if(response.output==true)
        {
          toastr.success('Data Saved Successfully');
          this.GetApplicants();
        }
        else
        {
          toastr.error('Data Saved UnSuccessfully');
        }
      } 
      else {
        if(typeof response.output !== "undefined")
        {
        toastr.error('Data Saved UnSuccessfully');
        }
        else
        {
          this.cleardata();
        }
      }
     
    });
  };
  GetApplicants() {
    this._ApplicantService.GetApplicants()
      .then(data => { this.results = data; })
      .catch(err => console.log(err));
  };
  Countrylist() {
    this._CountryService.GetCountries()
      .then(data => { this.countries = data })
      .catch(err => console.log(err));
  };
  public edit(id) {
    this.save = false;
    let ids = Number(id);
    this._ApplicantService.GetApplicantByID(ids)
      .then(contact => {
        this.data = contact;
        this.dialogService.open({ viewModel: apllicantpopup, model: [this.data, this.save, this.countries], lock: false }).whenClosed(response => {
          if (!response.wasCancelled) {
            if(response.output==true)
            {
              toastr.success('Data Saved Successfully');
              this.GetApplicants();
            }
            else
            {
              toastr.error('Data Saved UnSuccessfully');
            }
          } 
          else {
            if(typeof response.output !== "undefined")
            {
            toastr.error('Data Saved UnSuccessfully');
            }
            else
            {
              this.cleardata();
            }
          }
        });
      }).catch(err => console.log(err));
  };
  public delete(id) {
    this.dialogService.open({ viewModel: Prompt, model: 'Are you sure?' }).whenClosed(openDialogResult => {
      return openDialogResult;
    }).then((response) => {
      if (!response.wasCancelled) {
        let ids = Number(id);
        this._ApplicantService.DeleteApplicant(ids)
          .then(contact => {
            this.GetApplicants();
          }).catch(err => console.log(err));
      }
    });
  };

  cleardata()
  {
    this.data.id= null,
    this.data.name= null,
    this.data.familyName= null,
    this.data.address= null,
    this.data.countryOfOrigin= null,
    this.data.eMailAdress= null,
    this.data.age= null,
    this.data.hired= false
  }
}

interface applicants {
  ID: number,
  Name: string,
  FamilyName: string,
  Address: string,
  CountryOfOrigin: string,
  EMailAdress: string,
  Age: number,
  Hired: boolean
}

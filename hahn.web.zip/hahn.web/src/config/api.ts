export default {
  dev: "http://localhost:65532/api/v1.0/",
  prod: ""
}

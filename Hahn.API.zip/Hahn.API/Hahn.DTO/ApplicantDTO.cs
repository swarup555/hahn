﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace Hahn.DTO
{
    public class ApplicantDTO
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string FamilyName { get; set; }
        public string Address { get; set; }
        public string CountryOfOrigin { get; set; }
        public string EMailAdress { get; set; }
        public int Age { get; set; }
        public bool Hired { get; set; }
    }
    public class ApplicantDTOValidator : AbstractValidator<ApplicantDTO>
    {
        public ApplicantDTOValidator()
        {
            RuleFor(m => m.Name).NotEmpty().MinimumLength(5);
            RuleFor(m => m.FamilyName).NotEmpty().MinimumLength(5);
            RuleFor(m => m.Address).NotEmpty().MinimumLength(10);
            RuleFor(m => m.EMailAdress).NotEmpty().EmailAddress();
            RuleFor(x => x.CountryOfOrigin).Must(IsValidCountry);
            RuleFor(x => x.Age).NotEmpty().InclusiveBetween(20,60);
        }
        public bool IsValidCountry(string Country)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://restcountries.eu");
                MediaTypeWithQualityHeaderValue contentType = new MediaTypeWithQualityHeaderValue("application/json");
                client.DefaultRequestHeaders.Accept.Add(contentType);
                HttpResponseMessage response = client.GetAsync("/rest/v2/name/" + Country + "?fullText=true").Result;
                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                return false;
            }
        }
    }
  
}

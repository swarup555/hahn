﻿using Hahn.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.Business
{
    public interface IApplicantBusiness
    {
        List<ApplicantDTO> GetApplicants();
        ApplicantDTO GetApplicantByID(int ID);
        bool SaveApplicant(ApplicantDTO obj);
        bool UpdateApplicant(int ID,ApplicantDTO obj);
        bool DeleteApplicant(int ID);
    }
}

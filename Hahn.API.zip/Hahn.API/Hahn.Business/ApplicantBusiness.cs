﻿using Hahn.Data;
using Hahn.DTO;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.Business
{
    public class ApplicantBusiness : IApplicantBusiness
    {
        private readonly IApplicant _applicantobj;
        public ApplicantBusiness(IApplicant applicantobj)
        {
            _applicantobj =applicantobj;
        }
        public bool DeleteApplicant(int ID)
        {
            return _applicantobj.DeleteApplicant(ID);
        }

        public ApplicantDTO GetApplicantByID(int ID)
        {
            return _applicantobj.GetApplicantByID(ID);
        }

        public List<ApplicantDTO> GetApplicants()
        {
            return _applicantobj.GetApplicants();
        }

        public bool SaveApplicant(ApplicantDTO obj)
        {
            return _applicantobj.SaveApplicant(obj);
        }

        public bool UpdateApplicant(int ID,ApplicantDTO obj)
        {
            return _applicantobj.UpdateApplicant(ID,obj);
        }
    }
}

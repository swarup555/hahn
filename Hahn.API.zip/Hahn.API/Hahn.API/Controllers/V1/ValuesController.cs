﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Hahn.Business;
using Hahn.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Serilog;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hahn.API.Controllers.V1
{
    [ApiController]
    public class ValuesController : BaseController
    {
        readonly ILogger<ValuesController> _logger;
        readonly IDiagnosticContext _diagnosticContext;
        readonly IApplicantBusiness _applicantbusinessobj;
        // GET: api/<ValuesController>
        public ValuesController(ILogger<ValuesController> logger, IDiagnosticContext diagnosticContext, IApplicantBusiness applicantbusinessobj)
        {
            _logger = logger;
            _diagnosticContext = diagnosticContext;
            _applicantbusinessobj = applicantbusinessobj;
        }
        [HttpGet("[action]")]
        public IActionResult GetApplicants()
        {
            var data = _applicantbusinessobj.GetApplicants();
            return Ok(data);
        }

        // GET api/<ValuesController>/5
        [HttpGet("[action]/{id}")]
        public IActionResult GetApplicantByID(int id)
        {
            var data=_applicantbusinessobj.GetApplicantByID(id);
            return Ok(data);
        }

        // POST api/<ValuesController>
        [HttpPost("[action]")]
        public IActionResult SaveApplicant([FromBody] ApplicantDTO value)
        {
            var data = _applicantbusinessobj.SaveApplicant(value);
            return Ok(data);
        }

        // PUT api/<ValuesController>/5
        [HttpPut("[action]/{id}")]
        public IActionResult UpdateApplicant(int id, [FromBody] ApplicantDTO value)
        {
            var data = _applicantbusinessobj.UpdateApplicant(id,value);
            return Ok(data);
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("[action]/{id}")]
        public IActionResult DeleteApplicant(int id)
        {
            var data = _applicantbusinessobj.DeleteApplicant(id);
            return Ok(data);
        }
    }
}

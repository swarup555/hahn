using FluentValidation;
using FluentValidation.AspNetCore;
using Hahn.Business;
using Hahn.Data;
using Hahn.DTO;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Serilog;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Hahn.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers().AddFluentValidation();
            services.AddApiVersioning(o =>
            {
                o.ReportApiVersions = true;
                o.AssumeDefaultVersionWhenUnspecified = true;
                o.DefaultApiVersion = new ApiVersion(1, 0);
            });
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1.0",
                new OpenApiInfo
                {
                    Version = "1.0",
                    Title = "v1.0 API",
                    Description = "v1.0 API Description",
                });
                options.SwaggerDoc("v2.0",
               new OpenApiInfo
               {
                   Version = "2.0",
                   Title = "v2.0 API",
                   Description = "v2.0 API Description",
               });
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using the bearer scheme",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {new OpenApiSecurityScheme{Reference = new OpenApiReference
                    {
                        Id = "Bearer",
                        Type = ReferenceType.SecurityScheme
                    }}, new List<string>()}
                });
                options.OperationFilter<RemoveVersionFromParameter>();
                options.DocumentFilter<ReplaceVersionWithExactValueInPath>();
            });

            services.AddCors();
            services.AddDbContext<dbContext>(opt => opt.UseInMemoryDatabase(databaseName: "Applications"));
            services.AddScoped<dbContext>();
            services.AddTransient<IValidator<ApplicantDTO>, ApplicantDTOValidator>();
            services.AddTransient<IApplicantBusiness, ApplicantBusiness>();
            services.AddTransient<IApplicant, ApplicantImplementation>();
        }
        public class RemoveVersionFromParameter : IOperationFilter
        {
            public void Apply(OpenApiOperation operation, OperationFilterContext context)
            {
                var versionParameter = operation.Parameters.SingleOrDefault(x => x.Name == "version");
                operation.Parameters.Remove(versionParameter);
            }
        }
        public class ReplaceVersionWithExactValueInPath : IDocumentFilter
        {
            public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
            {
                if (swaggerDoc == null)
                    throw new ArgumentNullException(nameof(swaggerDoc));

                var replacements = new OpenApiPaths();

                foreach (var (key, value) in swaggerDoc.Paths)
                {
                    replacements.Add(key.Replace("{version}", swaggerDoc.Info.Version, StringComparison.InvariantCulture), value);
                }

                swaggerDoc.Paths = replacements;
            }
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, dbContext context)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors(builder => builder
                .AllowAnyHeader()
                .AllowAnyMethod()
                .SetIsOriginAllowed((host) => true)
                .AllowCredentials()
            );
            app.UseRouting();

            app.UseAuthorization();
            app.UseSerilogRequestLogging();
            context.Database.EnsureCreated();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint($"/swagger/v1.0/swagger.json", $"v1.0");
            });
        }
    }
}

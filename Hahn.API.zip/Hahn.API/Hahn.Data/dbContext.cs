﻿using Hahn.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.Data
{
    public class dbContext : DbContext
    {
        public dbContext(DbContextOptions<dbContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Applicant>().HasData(
                new Applicant
                {
                    ID = 1,
                    Name = "swarup",
                    FamilyName = "Shakespeare",
                    CountryOfOrigin="India",
                    EMailAdress="swaruplipuna@gmail.com",
                    Address="jajpur,odisha,india",
                    Age=28,
                    Hired=true
                }
            );
        }
        public DbSet<Applicant> Applicants { get; set; }

       
    }
}

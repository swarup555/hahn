﻿using Hahn.DTO;
using Hahn.Entity;
using Mapster;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hahn.Data
{
    public class ApplicantImplementation : IApplicant
    {

        private readonly dbContext _context;
        private readonly ILogger _logger;
        public ApplicantImplementation(dbContext context, ILogger<ApplicantImplementation> logger)
        {
            _context = context;
            _logger = logger;
        }
        public ApplicantDTO GetApplicantByID(int ID)
        {
            var data = _context.Applicants.Where(x => x.ID == ID).FirstOrDefault();
            return data.Adapt<ApplicantDTO>();
        }

        public bool SaveApplicant(ApplicantDTO obj)
        {
            bool status = false;
            try
            {
                var data = obj.Adapt<Applicant>();
                data.ID = (_context.Applicants.ToList().Count) + 1; 
                _context.Applicants.Add(data);
                _context.SaveChanges();
                status = true;
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return status;
        }

        public bool UpdateApplicant(int ID,ApplicantDTO obj)
        {
            bool status = false;
            try
            {
                var entity = _context.Applicants.Where(item => item.ID ==ID).FirstOrDefault();
                // Validate entity is not null
                if (entity != null)
                {
                    entity.Name = obj.Name;
                    entity.FamilyName = obj.FamilyName;
                    entity.EMailAdress = obj.EMailAdress;
                    entity.CountryOfOrigin = obj.CountryOfOrigin;
                    entity.Hired = obj.Hired;
                    entity.Address = obj.Address;
                    entity.Age = obj.Age;
                    _context.Applicants.Update(entity);
                    _context.SaveChanges();
                }
                status = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return status;
        }
        public bool DeleteApplicant(int ID)
        {
            bool status = false;
            try
            {
                var entity = _context.Applicants.Where(item => item.ID == ID).FirstOrDefault();
                // Validate entity is not null
                if (entity != null)
                {
                    _context.Applicants.Remove(entity);
                    _context.SaveChanges();
                }
                status = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return status;
        }

        public List<ApplicantDTO> GetApplicants()
        {
            var data = _context.Applicants.ToList();
            return data.Adapt<List<ApplicantDTO>>();
        }
    }
}
